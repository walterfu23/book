﻿using System.Threading.Tasks;

namespace SampleWebApiAspNetCore.Services
{
    public interface ISeedDataService
    {
        void EnsureSeedData();
    }
}
